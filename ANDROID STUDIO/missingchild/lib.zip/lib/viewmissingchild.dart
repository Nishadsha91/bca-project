//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
//
//
//
// import 'package:http/http.dart' as http;
//
//
// // import 'package:seatallocation/sent_complaint.dart';
// import 'dart:convert';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import 'homes.dart';
//
//
//
// class viewmissingcase extends StatefulWidget {
//   const viewmissingcase({super.key, required this.title});
//
//   final String title;
//
//   @override
//   State<viewmissingcase> createState() => _viewmissingcaseState();
// }
//
// class _viewmissingcaseState extends State<viewmissingcase> {
//
//
//
//   _viewmissingcaseState(){
//     viewmissingcase();
//   }
//   List<int> id_=[];
//   List<String> name_=[];
//   List<String> age_=[];
//   List<String> description_=[];
//   List<String> missingdate_=[];
//   List<String> uploaddate_=[];
//   List<String> photo_=[];
//
//
//
//
//   void viewmissingcase() async {
//     List<int> id = <int>[];
//     List<String> name = <String>[];
//     List<String> age = <String>[];
//     List<String> description = <String>[];
//     List<String>  missingdate = <String>[];
//     List<String> uploaddate = <String>[];
//     List<String> photo = <String>[];
//
//
//     try {
//       SharedPreferences sh = await SharedPreferences.getInstance();
//       String urls = sh.getString('url').toString();
//       String url = urls+'/user_view_missingcase';
//       // String lid = sh.getString("lid").toString();
//       var data = await http.post(Uri.parse(url), body: {
//         // "lid": lid,
//       });
//       var jsondata = json.decode(data.body);
//       String statuss = jsondata['status'];
//
//       var arr = jsondata["data"];
//
//       // print(arr.length);
//
//       for (int i = 0; i < arr.length; i++) {
//         id.add(arr[i]['id']);
//         name.add(arr[i]['childname']);
//         age.add(arr[i]['age']);
//         description.add(arr[i]['description'].toString());
//         missingdate.add(arr[i]['missingdate'].toString());
//         uploaddate.add(arr[i]['uploaddate'].toString());
//         // photo.add(arr[i]['photo'].toString());
//         // photo.add(sh.getString('imgurl').toString()+arr[i]['photo'].toString());
//         photo.add(sh.getString('imgurl').toString()+arr[i]['childimage']);
//
//
//       }
//
//       setState(() {
//         id_ = id;
//         name_ = name;
//         age_ = age;
//         description_ = description;
//         missingdate_ = missingdate;
//         uploaddate_ = uploaddate;
//         photo_ = photo;
//       });
//
//       print(statuss);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//       //there is error during converting file image to base64 encoding.
//     }
//   }
//
//
//
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//
//
//
//     return WillPopScope(
//       onWillPop: () async{ return true; },
//       child: Scaffold(
//         appBar: AppBar(
//           automaticallyImplyLeading: false,
//           backgroundColor: Colors.white,
//           elevation: 0.0,
//           leadingWidth: 0.0,
//           title: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CircleAvatar(
//                 backgroundColor: Colors.grey.shade300,
//                 radius: 20.0,
//                 child: IconButton(
//                   onPressed: () {
//                     Navigator.push(context,
//                         MaterialPageRoute(builder: (context) => MissingHome(),));                  },
//                   splashRadius: 1.0,
//                   icon: Icon(
//                     Icons.arrow_back_ios_new,
//                     color: Colors.green,
//                     size: 24.0,
//                   ),
//                 ),
//               ),
//               Text(
//                 'Missing Child',
//
//               ),
//               SizedBox(
//                 width: 40.0,
//                 child: IconButton(
//                   onPressed: () {},
//                   splashRadius: 1.0,
//                   icon: Icon(
//                     Icons.more_vert,
//                     color: Colors.white,
//                     size: 34.0,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//
//         body: ListView.builder(
//           physics: BouncingScrollPhysics(),
//           // padding: EdgeInsets.all(5.0),
//           // shrinkWrap: true,
//           itemCount: id_.length,
//           itemBuilder: (BuildContext context, int index) {
//             return ListTile(
//               onLongPress: () {
//                 print("long press" + index.toString());
//               },
//               title: Padding(
//                   padding: const EdgeInsets.all(0),
//                   child: Column(
//                     children: [
//                       Container(
//                         width: 400,
//                         child: Card(
//                           elevation: 6,
//                           margin: EdgeInsets.all(10),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(12),
//                           ),
//                           child: Container(
//                             color: Colors.white,
//                             padding: EdgeInsets.all(16),
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.center
//                                   ,
//                                   children: [
//                                     // CircleAvatar(
//                                     //   radius: 50.0,
//                                     //
//                                     //   backgroundImage: NetworkImage(photo_[index]),
//                                     // ),
//                                   ],
//                                 ),
//                                 Image.network(
//                                   photo_[index],
//                                   width: 500,
//                                   height: 250,
//                                   fit: BoxFit.cover, // You can adjust this property based on your requirement
//                                 ),
//
//
//
//
//
//
//                                 SizedBox(height: 8),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Text(
//                                       "Name         : ",
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                     Text(
//                                       '${name_[index]}',
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                   ],
//                                 ),   SizedBox(height: 8),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   children: [
//
//                                     Text(
//                                       "age         : ",
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                     Text(
//                                       '${age_[index]}',
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                   ],
//                                 ),
//
//
//
//
//
//                                 SizedBox(height: 8),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Text(
//                                       "Description         : ",
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                     Text(
//                                       '${description_[index]}',
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                   ],
//                                 ),
//
//
//
//
//
//                                 SizedBox(height: 8),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Text(
//                                       "missingdate         : ",
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                     Text(
//                                       '${missingdate_[index]}',
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                   ],
//                                 ),  SizedBox(height: 8),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                   children: [
//
//                                     Text(
//                                       "uploaddate         : ",
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                     Text(
//                                       '${uploaddate_[index]}',
//                                       style: TextStyle(fontSize: 16),
//                                     ),
//                                   ],
//                                 ),
//
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),
//
//
//
//
//                     ],
//                   )),
//             );
//           },
//         ),
//
//
//
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:missingchild/viewupdates.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'homes.dart'; // Replace with the correct import path for your MissingHome widget.

class viewmissingcase extends StatefulWidget {
  const viewmissingcase({super.key, required this.title});

  final String title;

  @override
  State<viewmissingcase> createState() => _viewmissingcaseState();
}

class _viewmissingcaseState extends State<viewmissingcase> {
  List<int> id_ = [];
  List<String> name_ = [];
  List<String> age_ = [];
  List<String> description_ = [];
  List<String> missingdate_ = [];
  List<String> uploaddate_ = [];
  List<String> photo_ = [];

  @override
  void initState() {
    super.initState();
    viewmissingcase();
  }

  void viewmissingcase() async {
    List<int> id = <int>[];
    List<String> name = <String>[];
    List<String> age = <String>[];
    List<String> description = <String>[];
    List<String> missingdate = <String>[];
    List<String> uploaddate = <String>[];
    List<String> photo = <String>[];

    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String urls = sh.getString('url').toString();
      String url = '$urls/user_view_missingcase';

      var data = await http.post(Uri.parse(url));
      var jsondata = json.decode(data.body);
      String statuss = jsondata['status'];
      var arr = jsondata["data"];

      for (int i = 0; i < arr.length; i++) {
        id.add(arr[i]['id']);
        name.add(arr[i]['childname']);
        age.add(arr[i]['age']);
        description.add(arr[i]['description'].toString());
        missingdate.add(arr[i]['missingdate'].toString());
        uploaddate.add(arr[i]['uploaddate'].toString());
        photo.add(sh.getString('imgurl').toString() + arr[i]['childimage']);
      }

      setState(() {
        id_ = id;
        name_ = name;
        age_ = age;
        description_ = description;
        missingdate_ = missingdate;
        uploaddate_ = uploaddate;
        photo_ = photo;
      });

      print(statuss);
    } catch (e) {
      print("Error ------------------- " + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          elevation: 0.0,
          leadingWidth: 0.0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CircleAvatar(
                backgroundColor: Colors.grey.shade300,
                radius: 20.0,
                child: IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MissingHome(),
                      ),
                    );
                  },
                  splashRadius: 1.0,
                  icon: Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.green,
                    size: 24.0,
                  ),
                ),
              ),
              Text(
                'Missing Child',
              ),
              SizedBox(
                width: 40.0,
                child: IconButton(
                  onPressed: () {},
                  splashRadius: 1.0,
                  icon: Icon(
                    Icons.more_vert,
                    color: Colors.white,
                    size: 34.0,
                  ),
                ),
              ),
            ],
          ),
        ),
        body: ListView.builder(
          physics: BouncingScrollPhysics(),
          itemCount: id_.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Padding(
                padding: const EdgeInsets.all(0),
                child: Column(
                  children: [
                    Container(
                      width: 400,
                      child: Card(
                        elevation: 6,
                        margin: EdgeInsets.all(10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Container(
                          color: Colors.white,
                          padding: EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.network(
                                photo_[index],
                                width: 500,
                                height: 250,
                                fit: BoxFit.cover,
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Name: ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  Text(
                                    '${name_[index]}',
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Age: ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  Text(
                                    '${age_[index]}',
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Description: ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  Flexible(
                                    child: Text(
                                      '${description_[index]}',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Missing Date: ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  Text(
                                    '${missingdate_[index]}',
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Upload Date: ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  Text(
                                    '${uploaddate_[index]}',
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ],
                              ),
                              SizedBox(height: 16),
                              Center(
                                child: ElevatedButton(
                                  onPressed: () {
                                    // Implement your logic to view updates for the selected case
                                    // Example: Navigate to an updates screen with case details
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => UpdatesScreen(
                                          caseId: id_[index],
                                          childName: name_[index],
                                        ),
                                      ),
                                    );
                                  },
                                  child: Text("View Updates"),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// class UpdatesScreen extends StatelessWidget {
//   final int caseId;
//   final String childName;
//
//   const UpdatesScreen({required this.caseId, required this.childName});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Updates for $childName"),
//       ),
//       body: Center(
//         child: Text("Display updates for case ID: $caseId"),
//       ),
//     );
//   }
// }
