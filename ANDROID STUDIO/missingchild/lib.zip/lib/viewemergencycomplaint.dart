import 'dart:convert';


import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:missingchild/homes.dart';

class Viewemergencycomplaint extends StatefulWidget {
  @override
  _ViewemergencycomplaintState createState() => _ViewemergencycomplaintState();
}

class _ViewemergencycomplaintState extends State<Viewemergencycomplaint> {
// Lists to store Viewemergencycomplaints and their replies
  List<String> Viewemergencycomplaints = [];
  List<String> replies = [];


  List<String> ccid_ = <String>[];
  List<String> message_ = <String>[];
  List<String> date_ = <String>[];
  List<String> status_ = <String>[];
  List<String> reply_ = <String>[];

  _ViewemergencycomplaintState(){
    load();
  }
  Future<void> load() async {
    List<String> ccid = <String>[];
    List<String> message = <String>[];
    List<String> date = <String>[];
    List<String> sts= <String>[];
    List<String> reply=  <String>[];
    // List<String> Viewemergencycomplaint = <String>[];


    try {
      final pref = await SharedPreferences.getInstance();
      String lid = pref.getString("lid").toString();
      String hid = pref.getString("hid").toString();
      String ip = pref.getString("url").toString();
      // String lid= pref.getString("lid").toString();

      String url = ip + "/user_view_emergency";
      print(url);
      var data = await http.post(Uri.parse(url), body: {
        'lid': lid,"hid":hid
      });

      var jsondata = json.decode(data.body);
      String status = jsondata['status'];

      var arr = jsondata["data"];

      print(arr);

      print(arr.length);

      // List<String> schid_ = <String>[];
      // List<String> date_ = <String>[];
      // List<String> type_ = <String>[];

      for (int i = 0; i < arr.length; i++) {
        ccid.add(arr[i]['id'].toString());
        message.add(arr[i]['message'].toString());
        date.add(arr[i]['date'].toString());
        sts.add(arr[i]['status'].toString());
        reply.add(arr[i]['reply'].toString());
        // Viewemergencycomplaint.add(arr[i]['user_view_emergency'].toString());
      }
      setState(() {
        ccid_ = ccid;
        message_ = message;
        date_ = date;
        status_ = sts;
        reply_ = reply;
        // Viewemergencycomplaint_ = Viewemergencycomplaint;
      });
      print(status);
    } catch (e) {
      print("Error ------------------- " + e.toString());
      //there is error during converting file image to base64 encoding.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Viewemergencycomplaints"),
      ),
      body: ListView.builder(
        physics: BouncingScrollPhysics(),
        // padding: EdgeInsets.all(5.0),
        // shrinkWrap: true,
        itemCount: ccid_.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
              onTap: () {


              },
              title: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Column(
                  children: [


                    Container(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,
                      height: 200,
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        child: Column(
                          children: [

                            SizedBox(height: 16,),
                            Row(

                              children: [
                                SizedBox(
                                  width: 10,
                                ),

                                Flexible(flex: 2,
                                    fit: FlexFit.loose,
                                    child: Row(children: [Text(" Date")])),
                                Flexible(flex: 3,
                                    fit: FlexFit.loose,
                                    child: Row(children: [Text(date_[index])])),

                                // Text("Place"),
                                // Text(place_[index])
                              ],
                            ),
                            SizedBox(height: 16,),
                            Row(

                              children: [
                                SizedBox(
                                  width: 10,
                                ),

                                Flexible(flex: 2,
                                    fit: FlexFit.loose,
                                    child: Row(children: [Text("message")])),
                                Flexible(flex: 3,
                                    fit: FlexFit.loose,
                                    child: Row(
                                        children: [Text(message_[index])])),

                                // Text("Place"),
                                // Text(place_[index])
                              ],
                            ),
                            SizedBox(height: 16,), Row(

                              children: [
                                SizedBox(
                                  width: 10,
                                ),

                                Flexible(flex: 2,
                                    fit: FlexFit.loose,
                                    child: Row(children: [Text("Reply")])),
                                Flexible(flex: 3,
                                    fit: FlexFit.loose,
                                    child: Row(
                                        children: [Text(reply_[index])])),

                                // Text("Place"),
                                // Text(place_[index])
                              ],
                            ),


                          ],
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        elevation: 5,
                        margin: EdgeInsets.all(10),
                      ),
                    ),


                  ],
                ),
              )


          );
        },

      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
// Navigate to the New Viewemergencycomplaint page when the button is pressed
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => NewViewemergencycomplaintPage(),
            ),
          ).then((newViewemergencycomplaint) {
// Add the new Viewemergencycomplaint to the list (if provided)
            if (newViewemergencycomplaint != null) {
              setState(() {
                Viewemergencycomplaints.add(newViewemergencycomplaint);
                replies.add("Admin Reply for New Viewemergencycomplaint");
              });
            }
          });
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class NewViewemergencycomplaintPage extends StatefulWidget {
  @override
  _NewViewemergencycomplaintPageState createState() => _NewViewemergencycomplaintPageState();
}

class _NewViewemergencycomplaintPageState extends State<NewViewemergencycomplaintPage> {
  final TextEditingController _ViewemergencycomplaintController = TextEditingController();

  @override
  void dispose() {
    _ViewemergencycomplaintController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Write a New Viewemergencycomplaint"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _ViewemergencycomplaintController,
              decoration: InputDecoration(
                hintText: "Enter your Compalint...",
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                final sh = await SharedPreferences.getInstance();
                String Viewemergencycomplaint = _ViewemergencycomplaintController.text.toString();
                // String Passwd=passwordController.text.toString();
                String url = sh.getString("url").toString();
                String lid = sh.getString("lid").toString();
                String hid = sh.getString("hid").toString();
                print("okkkkkkkkkkkkkkkkk");
                var data = await http.post(
                    Uri.parse(url + "/sendemgcomplaint"),
                    body: {'msg': Viewemergencycomplaint,
                      'lid': lid,
                      'hid': hid,

                    });
                var jasondata = json.decode(data.body);
                String status = jasondata['task'].toString();
                if (status == "ok") {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => MissingHome()));
                }
                else {
                  print("error");
                }
              },
              child: Text("Submit Viewemergencycomplaint"),
            ),
          ],
        ),
      ),
    );
  }
}
