
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';



import 'package:http/http.dart' as http;


// import 'package:seatallocation/sent_complaint.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'homes.dart';



class ViewNotification extends StatefulWidget {
  const ViewNotification({super.key, required this.title});

  final String title;

  @override
  State<ViewNotification> createState() => _ViewNotificationState();
}

class _ViewNotificationState extends State<ViewNotification> {



  _ViewNotificationState(){
    ViewNotification();
  }
  List<int> id_=[];
  List<String> heading_=[];
  List<String> description_=[];
  List<String> date_=[];





  void ViewNotification() async {
    List<int> id = <int>[];
    List<String> h = <String>[];
    List<String> description = <String>[];
    List<String>  date = <String>[];



    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String urls = sh.getString('url').toString();
      String url = urls+'/user_view_notification';
      // String lid = sh.getString("lid").toString();
      var data = await http.post(Uri.parse(url), body: {
        // "lid": lid,
      });
      var jsondata = json.decode(data.body);
      String statuss = jsondata['status'];

      var arr = jsondata["data"];


      print(arr.length);

      for (int i = 0; i < arr.length; i++) {
        id.add(arr[i]['id']);
        h.add(arr[i]['heading']);
        description.add(arr[i]['description'].toString());
        date.add(arr[i]['date'].toString());



      }

      setState(() {
        id_ = id;
        heading_= h;
        description_ = description;
        date_ = date;
      });

      print(statuss);
    } catch (e) {
      print("Error ------------------- " + e.toString());
      //there is error during converting file image to base64 encoding.
    }
  }







  @override
  Widget build(BuildContext context) {



    return WillPopScope(
      onWillPop: () async{ return true; },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          elevation: 0.0,
          leadingWidth: 0.0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CircleAvatar(
                backgroundColor: Colors.grey.shade300,
                radius: 20.0,
                child: IconButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MissingHome(),));                  },
                  splashRadius: 1.0,
                  icon: Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.green,
                    size: 24.0,
                  ),
                ),
              ),
              Text(
                'Missing Child',

              ),
              SizedBox(
                width: 40.0,
                child: IconButton(
                  onPressed: () {},
                  splashRadius: 1.0,
                  icon: Icon(
                    Icons.more_vert,
                    color: Colors.white,
                    size: 34.0,
                  ),
                ),
              ),
            ],
          ),
        ),

        body: ListView.builder(
          physics: BouncingScrollPhysics(),
          // padding: EdgeInsets.all(5.0),
          // shrinkWrap: true,
          itemCount: id_.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              onLongPress: () {
                print("long press" + index.toString());
              },
              title: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    children: [
                      Container(
                        width: 400,
                        child: Card(
                          elevation: 6,
                          margin: EdgeInsets.all(10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Container(
                            color: Colors.white,
                            padding: EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center
                                  ,
                                  children: [
                                    // CircleAvatar(
                                    //   radius: 50.0,
                                    //
                                    //   backgroundImage: NetworkImage(photo_[index]),
                                    // ),
                                  ],
                                ),
                                // Image.network(
                                //   photo_[index],
                                //   width: 500,
                                //   height: 250,
                                //   fit: BoxFit.cover, // You can adjust this property based on your requirement
                                // ),






                                SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "headingg         : ",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    Text(
                                      '${heading_[index]}',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ],
                                ),   SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [

                                    Text(
                                      "description         : ",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    Text(
                                      '${description_[index]}',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ],
                                ),



                                SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "date         : ",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    Text(
                                      '${date_[index]}',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ],
                                ),
                            // SizedBox(height: 8),
                            //     Row(
                            //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            //       children: [
                            //
                            //
                            //     // SizedBox(height: 8),
                            //     //
                            //     // Row(
                            //     //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            //     //   children: [
                            //     //
                            //     //     ElevatedButton(onPressed: () async{
                            //     //       SharedPreferences sh=await SharedPreferences.getInstance();
                            //     //       sh.setString('fid', id_[index].toString());
                            //     //
                            //     //
                            //     //
                            //     //       Navigator.push(
                            //     //           context,
                            //     //           MaterialPageRoute(builder: (context) => user_view_productlessfull222(title: '',))
                            //     //       );
                            //     //
                            //     //     },style: ElevatedButton.styleFrom(
                            //     //         backgroundColor: Colors.green
                            //     //
                            //     //     ),
                            //     //         // child: Icon(Icons.),
                            //     //         child: Text('Products',style: TextStyle(color: Colors.white),)
                            //     //     ),
                            //     //   ],
                            //     // ),SizedBox(height: 8),
                            //
                            //
                              ],
                            ),
                          ),
                        ),
                      ),




                    ],
                  )),
            );
          },
        ),
        // floatingActionButton: FloatingActionButton(onPressed: () {
        //
        //   Navigator.push(
        //       context,
        //       MaterialPageRoute(builder: (context) => compl(title: '',)));
        //
        // },backgroundColor: Colors.lightBlueAccent,
        //
        //   child: Icon(Icons.add),
        // ),


      ),
    );
  }
}
