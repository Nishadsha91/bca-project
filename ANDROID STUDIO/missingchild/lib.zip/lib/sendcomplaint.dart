
// Replace with the correct import for your project

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:missingchild/viewcomplaint.dart';
// import 'package:organdonation/complaintreply.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SendComplaintPage extends StatefulWidget {
  @override
  _SendComplaintPageState createState() => _SendComplaintPageState();
}

class _SendComplaintPageState extends State<SendComplaintPage> {
  TextEditingController complaintController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ADD COMPLAINTS",style:TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue[800],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 60),
                Padding(
                  padding: EdgeInsets.all(15),
                  child: TextFormField(
                    maxLines: 4,
                    controller: complaintController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Complaint",
                      prefixIcon: const Icon(Icons.report),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value.isEmpty) {
                        return "Please enter a complaint.";
                      }
                      return null;
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _sendComplaint();
                    }
                  },
                  child: _isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text('SEND COMPLAINTS',style: TextStyle(color: Colors.white),),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[800],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _sendComplaint() async {
    String complaintText = complaintController.text.trim();

    if (complaintText.isEmpty) {
      Fluttertoast.showToast(msg: "Complaint cannot be empty.");
      return;
    }

    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? lid = prefs.getString('lid');  // Get the user ID (login ID)
    String? url = prefs.getString('url');  // Get the base URL for the API

    if (lid == null || url == null) {
      Fluttertoast.showToast(msg: 'User ID or URL not found.');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(url + "/complaint_and_reply"),
        body: {
          'description': complaintText,
          'lid': lid,
        },
      );

      setState(() {
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Complaint Sent');
          complaintController.clear();
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => ViewRepliesPage()), // Redirect to Home
          );
        } else {
          Fluttertoast.showToast(msg: 'Failed to send complaint.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Error: Failed to send complaint.');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }
}
