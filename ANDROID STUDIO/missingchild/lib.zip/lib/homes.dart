
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:missingchild/sendfeedback.dart';
import 'package:missingchild/view%20notification.dart';
import 'package:missingchild/viewchildhelpline.dart';
import 'package:missingchild/viewcomplaint.dart';
import 'package:missingchild/viewemergencycomplaint.dart';
import 'package:missingchild/viewmissingchild.dart';

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';


import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';

void main() {
  runApp(MaterialApp(
    home: MissingHome(),
    debugShowCheckedModeBanner: false,
  ));
}

class MissingHome extends StatefulWidget {
  @override
  _MissingHomeState createState() => _MissingHomeState();
}

class _MissingHomeState extends State<MissingHome> {
  List<int> id_ = [];
  List<String> name_ = [];
  List<String> author_name_ = [];
  List<String> genre_ = [];
  List<String> price_ = [];
  List<String> photo_ = [];
  List<String> publish_year_ = [];
  List<String> details_ = [];
  List<String> stock_ = [];

  List<int> filteredIds = [];
  List<String> filteredNames = [];
  List<String> filteredAuthors = [];
  List<String> filteredGenres = [];
  List<String> filteredPrices = [];
  List<String> filteredPhotos = [];
  List<String> filteredYears = [];
  List<String> filteredDetails = [];
  List<String> filteredStocks = [];

  String searchQuery = "";

  final List<String> imagePaths = [
    'assets/child1.jpg',
    'assets/child2.jpg',
    'assets/child3.jpg',
    'assets/child4.jpg',
    'assets/child5.jpg',
  ];
  int _selectedIndex = 0;
  List filteredBooks = [];
  @override
  void initState() {
    super.initState();
    view_pets();
  }

  Future<void> view_pets() async {

    List filteredBooks;
    List<int> id = <int>[];
    List<String> name = <String>[];
    List<String> author_name = <String>[];
    List<String> genre = <String>[];
    List<String> price = <String>[];
    List<String> photo = <String>[];
    List<String> publish_year = <String>[];
    List<String> details = <String>[];
    List<String> stock = <String>[];

    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String urls = sh.getString('url').toString();
      String url = urls + 'view_books';

      var data = await http.post(Uri.parse(url), body: {});
      var jsondata = json.decode(data.body);
      String statuss = jsondata['status'];
      var arr = jsondata["data"];
      // filteredBooks=jsondata["data"];
      for (int i = 0; i < arr.length; i++) {
        id.add(arr[i]['id']);
        name.add(arr[i]['name']);
        author_name.add(arr[i]['author_name'].toString());
        genre.add(arr[i]['genre'].toString());
        price.add(arr[i]['price'].toString());
        publish_year.add(arr[i]['publish_year'].toString());
        stock.add(arr[i]['stock'].toString());
        details.add(arr[i]['details'].toString());
        photo.add(sh.getString('imgurl').toString() + arr[i]['image']);
      }
      filteredBooks = arr;
      print("************************************");
      print("************************************");
      print("************************************");
      print(filteredBooks);
      print(filteredBooks.length);
      setState(() {

        id_ = id;
        name_ = name;
        genre_ = genre;
        author_name_ = author_name;
        price_ = price;
        photo_ = photo;
        stock_ = stock;
        details_ = details;
        publish_year_ = publish_year;

        // Initialize filtered data with the complete list
        filteredIds = id_;
        filteredNames = name_;
        filteredAuthors = author_name_;
        filteredGenres = genre_;
        filteredPrices = price_;
        filteredPhotos = photo_;
        filteredYears = publish_year_;
        filteredDetails = details_;
        filteredStocks = stock_;
      });

      print(statuss);
    } catch (e) {
      print("Error ------------------- " + e.toString());
    }
  }

  void updateSearchResults(String query) {
    setState(() {
      searchQuery = query.toLowerCase();
      filteredIds = [];
      filteredNames = [];
      filteredAuthors = [];
      filteredGenres = [];
      filteredPrices = [];
      filteredPhotos = [];
      filteredYears = [];
      filteredDetails = [];
      filteredStocks = [];

      for (int i = 0; i < name_.length; i++) {
        if (name_[i].toLowerCase().contains(searchQuery) ||
            author_name_[i].toLowerCase().contains(searchQuery)) {
          filteredIds.add(id_[i]);
          filteredNames.add(name_[i]);
          filteredAuthors.add(author_name_[i]);
          filteredGenres.add(genre_[i]);
          filteredPrices.add(price_[i]);
          filteredPhotos.add(photo_[i]);
          filteredYears.add(publish_year_[i]);
          filteredDetails.add(details_[i]);
          filteredStocks.add(stock_[i]);
        }
      }
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    // Navigate to corresponding page on tap
    switch (index) {
      case 0:
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => viewebook()));
        break;
      case 1:
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => ViewMyBooks(title: '',)));
        break;
      case 2:
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => My_Issued_Books()));
        break;
      case 3:
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => PublishBooks(title: '',)));
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Show a dialog asking the user to confirm
        bool shouldLeave = await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Are you sure?'),
            content: Text('Do you want to exit the app?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text('No'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage(),));
                },
                child: Text('Yes'),
              ),
            ],
          ),
        );

        // Return whether the user wants to pop
        return shouldLeave ?? false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.brown,
          elevation: 0,
          title: Text(
            ' MissingHome',
            style: TextStyle(color: Colors.black),
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.brown,
                ),
                child: Text(
                  'Book Explorer',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.home_outlined),
                title: Text('Home'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                // leading: Icon(Icons.),
                title: Text('Books'),
                onTap: () {
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => Books(),));
                },
              ),
              ListTile(
                leading: Icon(Icons.collections_bookmark_outlined),
                title: Text('Missing Case'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => viewmissingcase(title: '',),));
                },
              ), ListTile(
                leading: Icon(Icons.book_outlined),
                title: Text('Notification'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ViewNotification(title: '',),));
                },
              ),
              // ListTile(
              //   leading: Icon(Icons.person_outline_outlined),
              //   title: Text('emergencycomplaint'),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(builder: (context) => Viewemergencycase(title: '',),));
              //   },
              // ),
              ListTile(
                leading: Icon(Icons.child_care),
                title: Text('Child Helpline'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Viewchildhelpline(title: '',),));
                },
              ),
              ListTile(
                leading: Icon(Icons.public_outlined),
                title: Text('Send_Feedback'),
                onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context) => user_feed(title: '',),));
                },
              ),
              ListTile(
                leading: Icon(Icons.report_gmailerrorred),
                title: Text('Complaints'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ViewRepliesPage(),));
                },
              ),

              ListTile(
                leading: Icon(Icons.logout),
                title: Text('Logout'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage(),));
                },
              ),
            ],
          ),
        ),

        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/3.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: ListView(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: TextField(
                  onChanged: updateSearchResults,
                  decoration: InputDecoration(
                    labelText: 'Search by Book Name or Author',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    prefixIcon: Icon(Icons.search, color: Colors.black54),
                    fillColor: Colors.white,
                    filled: true,
                    contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 20.0),
                  ),
                ),
              ),
              CarouselSlider(
                items: imagePaths.map((imagePath) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Container(
                        width: double.infinity,
                        margin: EdgeInsets.symmetric(horizontal: 5.0),
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(imagePath),
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  );
                }).toList(),
                options: CarouselOptions(
                  height: 200.0,
                  enlargeCenterPage: true,
                  enableInfiniteScroll: true,
                  autoPlay: true,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 8.0,
                    mainAxisSpacing: 8.0,
                    childAspectRatio: 0.7,
                  ),
                  itemCount: filteredNames.length,

                  itemBuilder: (context, index) {


                    // name.add(arr[i]['name']);
                    // author_name.add(arr[i]['author_name'].toString());
                    // genre.add(arr[i]['genre'].toString());
                    // price.add(arr[i]['price'].toString());
                    // publish_year.add(arr[i]['publish_year'].toString());
                    // stock.add(arr[i]['stock'].toString());
                    // details.add(arr[i]['details'].toString());
                    // photo.add(sh.getString('imgurl').toString() + arr[i]['image']);
                    var book = {"name":filteredNames[index]
                      ,"author_name":filteredAuthors[index]
                      ,"genre":filteredGenres[index]
                      ,"price":filteredPrices[index]
                      ,"publish_year":filteredYears[index]
                      ,"stock":filteredStocks[index]
                      ,"details":filteredDetails[index]
                      ,"photo":filteredPhotos[index]
                      ,"id":filteredIds[index]

                    };
                    return
                      Card(
                      elevation: 4.0,
                          shape: RoundedRectangleBorder(  // Add shape to Card to give border radius
                            borderRadius: BorderRadius.circular(16.0),  // Adjust the radius as needed
                          ),

                      child:InkWell( // Wrap with InkWell for tap effects
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => BookDetailPage(book: book)
                              ,
                            ),
                          );
                    },child:
                    Column(
                        children: [
                          Image.network(
                            filteredPhotos[index],
                            height: 200,
                            fit: BoxFit.cover,
                            width: double.infinity,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              filteredNames[index],
                              style: TextStyle(fontWeight: FontWeight.bold),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                      ),)
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          backgroundColor: Colors.black, // Background color
          selectedItemColor: Colors.black, // Icon color for selected items
          unselectedItemColor: Colors.grey, // Icon color for unselected items
          selectedLabelStyle: TextStyle(
            color: Colors.black, // Text color for selected label
            fontWeight: FontWeight.bold, // Optional: Make selected text bold
          ),
          unselectedLabelStyle: TextStyle(
            color: Colors.grey, // Text color for unselected label
          ),
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.book),
              label: 'Books',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'My Books',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.people),
              label: 'Students',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.publish),
              label: 'Publish',
            ),
          ],
        ),


      ),




    );
  }
}


class BookDetailPage extends StatelessWidget {
  final Map book;

  const BookDetailPage({Key? key, required this.book}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(book['name'] ?? 'Book Details'),
      ),
      body: FutureBuilder<SharedPreferences>(
        future: SharedPreferences.getInstance(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error loading preferences'));
          }

          final sh = snapshot.data;
          final imgUrl = sh?.getString('imgurl') ?? ''; // Get base URL for images

          // Concatenate the base URL with the image path from the API response
          final imageUrl = book['photo'] ?? '';

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(  // Added scroll view
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Display the image
                  imageUrl.isNotEmpty
                      ? Image.network(
                    imageUrl,
                    height: 500.0,  // Set the desired height
                    width: 500.0,   // Set the desired width
                  )
                      : const Icon(Icons.image, size: 100), // Placeholder icon if no image
                  const SizedBox(height: 16),
                  Text('Author: ${book['author_name'] ?? 'Unknown Author'}'),
                  const SizedBox(height: 8),
                  Text('Genre: ${book['genre'] ?? 'Unknown Genre'}'),
                  const SizedBox(height: 8),
                  Text('Published Year: ${book['publish_year'] ?? 'Unknown Year'}'),
                  const SizedBox(height: 8),
                  Text('Price: \$${book['price'] ?? '0.00'}'),
                  const SizedBox(height: 8),
                  Text('Stock: ${book['stock'] ?? '0'}'),
                  const SizedBox(height: 16),
                  Text('Details:'),
                  const SizedBox(height: 8),
                  Text(book['details'] ?? 'No details available.'),

                  SizedBox(height: 8),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          SharedPreferences sh =
                          await SharedPreferences.getInstance();
                          sh.setString('bid', book['id'].toString());
                          Fluttertoast.showToast(msg: book['id'].toString());

                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //       builder: (context) => UserFeedback(title: '',)),
                          // );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                        ),
                        child: Text(
                          'Rating',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          SharedPreferences sh =
                          await SharedPreferences.getInstance();
                          sh.setString('bid', book['id'].toString());
                          Fluttertoast.showToast(msg: book['id'].toString());

                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //       builder: (context) => View_Feedback(title: '',)),
                          // );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.pink,
                        ),
                        child: Text(
                          'View Rating',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      final sh = await SharedPreferences.getInstance();

                      String url = sh.getString("url").toString();
                      String lid = sh.getString("lid").toString();
                      print("Attempting to login...");

                      var data = await http.post(
                        Uri.parse(url + "user_reserve_booK"),
                        body: {
                          'bid': book['id'].toString(),
                          'lid': lid,
                        },
                      );

                      var jasondata = json.decode(data.body);
                      String status = jasondata['task'].toString();
                      if (status == "ok") {
                        Fluttertoast.showToast(msg: 'reserved for 1 hour.');
                      } else if (status == "not") {
                        Fluttertoast.showToast(msg: 'Already reserved.');
                      } else {
                        Fluttertoast.showToast(msg: 'Ok.');
                        print("Error: Invalid user type");
                      }
                    },
                    style: ElevatedButton.styleFrom(),
                    child: Text(
                      'RESERVE BOOK',
                      style: TextStyle(color: Colors.brown),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );


  }
}

