import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:missingchild/homes.dart';
import 'package:missingchild/sendcomplaint.dart';



import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';




class ViewRepliesPage extends StatefulWidget {
  const ViewRepliesPage({super.key});

  @override
  State<ViewRepliesPage> createState() => _ViewRepliesPageState();
}

class _ViewRepliesPageState extends State<ViewRepliesPage> {
  List<String> reply = [];
  List<String> description = [];
  List<String> date = [];

  @override
  void initState() {
    super.initState();
    loadReplies();
  }

  Future<void> loadReplies() async {
    try {
      final pref = await SharedPreferences.getInstance();
      String url = "${pref.getString("url") ?? ''}/user_view_complaint";
      print(url);
      print('======comp==================');

      print("API URL: $url");
      var response = await http.post(
        Uri.parse(url),
        body: {'lid': pref.getString("lid")},
      );

      print("Response body: ${response.body}");
      var jsonData = json.decode(response.body);
      String status = jsonData['status'];

      if (status == "ok") {
        var data = jsonData["data"];
        for (var item in data) {
          reply.add(item['reply'].toString());
          description.add(item['description'].toString());
          date.add(item['date'].toString());

        }

        setState(() {});
      } else {
        print("Error: ${jsonData['message']}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> deleteComplaint(String compId) async {
    try {
      final pref = await SharedPreferences.getInstance();
      String url = "${pref.getString("url") ?? ''}delete_complaint";

      var response = await http.post(
        Uri.parse(url),
        body: {'comp_id': compId},
      );

      var jsonData = json.decode(response.body);
      String status = jsonData['status'];

      if (status == "ok") {
        Fluttertoast.showToast(msg: "Complaint deleted successfully");
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MissingHome()),
        );
      } else {
        Fluttertoast.showToast(msg: "Failed to delete complaint");
      }
    } catch (e) {
      print("Error: $e");
      Fluttertoast.showToast(msg: "An error occurred");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "COMPLAINTS",
          style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue[800],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: reply.isEmpty
          ? const Center(
        child: Text(
          "No replies found.",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
      )
          : ListView.builder(
        itemCount: reply.length,
        itemBuilder: (BuildContext context, int index) {
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,  // Align button to the right
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          // deleteComplaint(complaintIds[index]);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,  // Button color
                          minimumSize: const Size(80, 36),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("DELETE",style: TextStyle(color: Colors.white),),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "description: ${description[index]}",
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Reply: ${reply[index]}",
                    style: const TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Date: ${date[index]}",
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>  SendComplaintPage(),
            ),
          );
        },
        backgroundColor: Colors.blue[800],
        elevation: 5,
        child: const Icon(Icons.add,),
      ),
    );
  }
}
